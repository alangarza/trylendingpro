<?php

$utm_params= $_REQUEST['utm-params'];
$debtAmount= $_REQUEST['debtAmount'];
$agreeDebt= $_REQUEST['agreeDebt'];
$radio= $_REQUEST['radio'];
$state= $_REQUEST['state'];
$address= $_REQUEST['address'];
$city= $_REQUEST['city'];
$zip= $_REQUEST['zip'];
$firstName= $_REQUEST['firstName'];
$lastName= $_REQUEST['lastName'];
$phone= $_REQUEST['phone'];
$email= $_REQUEST['email'];

echo $utm_params;
echo $debtAmount;
echo $agreeDebt;
echo $radio;
echo $state;
echo $address;
echo $city;
echo $zip;
echo $firstName;
echo $lastName;
echo $phone;
echo $email;

?>


